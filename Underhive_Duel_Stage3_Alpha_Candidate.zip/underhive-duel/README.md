# Underhive Duel — Stage 3 alpha candidate

**PROTOTYPE GATE: NOT READY.** The implementation and deterministic/integration tests are supplied. Public hosting and browser/device acceptance remain blocked; no public test URL has been published. This is not a submission-ready release.

Frozen authority: `rulesVersion: 0.1.0`, `visualVersion: 0.1.0`. Six unchanged champions and weapon traits. Foundry Background Study is the default arena. No Stage 4 balance changes or balance screening were performed.

## Run locally

Requires Node.js 22 or newer. The application has **zero npm dependencies**.

```sh
npm test
npm start
```

Open `http://localhost:3000` in a browser. Create a room and share its six-character code with the second player. For two devices on one network, both open `http://YOUR_COMPUTER_LAN_IP:3000`; permit the service through the local firewall. Public play requires an HTTPS host reachable by both devices.

A local two-player match is also available from the start screen. Expand **Local two-player match**, keep or change the deterministic seed, then pass the device when prompted. There is no AI player. Local mode does not persist after reload.

For a different port:

```sh
PORT=8080 npm start
```

In Windows PowerShell, set `$env:PORT=8080` before `npm start`.

## How to play

1. Both players choose any of the six champions and lock privately. Choices reveal together.
2. Higher initiative die becomes attacker. Ties reroll both.
3. If offered, select eligible dice for Balanced or Ceaseless, or pass. Ceaseless selections share one face.
4. Select one untouched die for Command Re-roll, or pass. Limit: once per player per bout, two tokens per match. Both choices lock before replacements roll.
5. On your turn, select one available success. **Strike** deals its weapon damage. **Block** then an eligible enemy die cancels that die. Cancel Block returns to your selection. Brutal requires a critical Block.
6. Zero Wounds immediately ends a bout as O.O.A. Otherwise, when both pools empty, lower percentage Wounds lost wins; an exact tie goes to the attacker. The result shows fractions and percentages.
7. Both acknowledge the next bout. First to three wins. Both must request a rematch, which resets champions, scores and tokens.

Keep the original tab for reconnection. A room code does not reclaim a seat. Opening the private seat in a replacement connection invalidates its old connection.

## Source map

- `public/lib/engine.js`: shared pure rules transitions; injected dice source for deterministic tests/local mode.
- `public/lib/roster.js`, `public/champions.json`: exact frozen champion data.
- `server/rooms.js`: sole authoritative room state, random dice, private views, receipts, leases and lifecycle.
- `server/http.js`: dependency-free HTTP service and static file delivery.
- `public/app.js`, `style.css`: playable UI, selection, fight, results and rematch.
- `public/lib/remote.js`: authenticated room transport; client sends intents only.
- `public/lib/local.js`: deterministic same-device controller.
- `public/lib/sprites.js`: exact atlas rectangles, masks, pivots and opponent mirroring.
- `public/assets/`: original Stage 2 assets and adopted Foundry background.
- `authority/`: internal frozen documents and hashes; this directory is never served.
- `test/`: executable rules, room, HTTP, transport and asset acceptance fixtures.
- `docs/`: actual test output, gate report, architecture, known issues and crop proof.

## Tests

```sh
npm run test:rules
npm run test:multiplayer
npm run test:assets
npm test
```

`test/rules.test.js` executes R01–R23 and R25–R32, including every intermediate wound value in the five-bout worked match and all 12,800 surviving-state percentage comparisons. R24 is executed by room receipt tests. Further room tests exercise actual two-bout token expenditure, secrecy, stale commands, cross-room authentication, forged data, reconnect in all choice/resolution phases, connection replacement, 60-second expiry, lost rooms and mutual rematch.

HTTP integration uses two independent clients against a real listening local service. The actual remote transport module is also exercised. **These are protocol/transport tests, not a completed two-device browser smoke test.**

To run the supplied browser acceptance script in an environment that can install Chromium:

```sh
npm install --no-save playwright
npx playwright install chromium
node scripts/browser-smoke.mjs
```

It launches two isolated browser contexts (desktop and touch mobile emulation), plays three matches covering all six champions, requests rematches, reloads a seat, and checks/screenshots entry/fight/result layouts at 320, 390, 768 and 1280 CSS pixels. Browser contexts are not physical devices. The current recorded attempt is **BLOCKED before browser launch**, and must be replaced by real passing evidence before publication. See `docs/MANUAL_SMOKE_TEST.md` for physical-device and keyboard checks.

## Hosting topology

Deploy **one** Node process, reachable by HTTPS, serving this static client and `/api` on one origin. Use the included Dockerfile, or the native command `npm start`, on a host that supports a continuously running Node service. Bind is `0.0.0.0`; `PORT` is supplied by the host. Health endpoint: `/health`.

- No SQL, accounts, matchmaking, progression, external services or persistent volumes.
- Do not autoscale to independent replicas. Each process would have unrelated rooms.
- No persistent disk is needed. Restart/deploy loses live rooms, and clients receive a clear room-expired/restarted message.
- A generic stateless Worker without room affinity cannot replace this service. No unsupported binding or per-isolate in-memory workaround is shipped.
- Do not publish until the requested browser and two-device gates pass.

See `docs/DEPLOYMENT.md` for concrete setup and remaining publication blockers.
